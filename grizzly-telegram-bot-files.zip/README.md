# grizzly-telegram-bot

Telegram bot that uses GrizzlySMS API to fetch numbers and activation codes.
